# Jenkins in Docker

A self-contained Jenkins controller plus a Docker-in-Docker (DinD) daemon that
builds, tests, scans and deploys the SecureShareFR stack end to end. The app
stack runs inside DinD, with ports 80/443 published to the host, so
`https://localhost` works after a successful build.

## Start

```bash
docker compose -f deploy/jenkins/docker-compose.yml up -d --build
```

Open <http://localhost:8080>, sign in with `admin` / `admin` (change the password
with `JENKINS_ADMIN_PASSWORD` before starting). The job **secureshare-deploy** is
created automatically from `Jenkinsfile` by Configuration as Code.

Click **Build Now**. Parameters:

| Parameter | Default | Meaning |
|---|---|---|
| `RUN_TESTS` | `true` | `npm ci`, lint, 116 tests, client build, prod audit |
| `RUN_SMOKE` | `true` | 25-check end-to-end test over HTTPS after deploy |
| `FAIL_ON_VULNS` | `false` | Fail on HIGH/CRITICAL Trivy findings (report-only by default) |
| `DEPLOY_TAG` | blank | Fixed image tag; blank uses `jenkins-$BUILD_NUMBER` |

## What the pipeline does

1. Waits for the DinD TLS daemon, then copies the mounted read-only source tree
   (`/workspace`) into the Jenkins workspace, excluding `node_modules` and `dist`.
2. Creates `deploy/.env` and `secrets/` if missing, and (re)generates the local
   self-signed TLS cert with a `docker` SAN so the in-network smoke test can
   verify it. Existing valid certs are left alone.
3. Installs dependencies and runs lint + tests + build + production audit.
4. Builds `secureshare-{api,authority,web}:$TAG` with `docker compose build`.
   Builds use the host network so npm can resolve the registry from nested builds.
5. Trivy-scans each image for CRITICAL/HIGH vulnerabilities (report-only unless
   `FAIL_ON_VULNS=true`).
6. Runs `docker compose up -d --remove-orphans` against the DinD daemon.
7. Waits for `https://docker/api/health` and `/authority/health`, checks `/docs`,
   then runs the smoke test against `https://docker`.
8. On success records the tag as last-good; on failure redeploys the last-good
   tag (`secureshare-last-good-tag` in `jenkins_home`).

Useful endpoints after a successful build: `https://localhost`,
`https://localhost/docs`, `https://localhost/api/openapi.json`.

## Notes

- The Jenkins container shares `jenkins_home` with the DinD daemon at the same
  absolute path. That is what makes bind-mounted secrets in the app compose file
  resolve correctly inside the nested daemon.
- Docker Desktop nested containers need the host network during build for npm
  registry DNS; the app compose build definitions set `network: host`.
- The source tree is mounted read-only; Jenkins never modifies your checkout.
- After editing `Jenkinsfile`, restart Jenkins so CasC regenerates the job:
  `docker compose -f deploy/jenkins/docker-compose.yml restart`.
- Stop everything with `docker compose -f deploy/jenkins/docker-compose.yml down`.
  This also removes the published 80/443 endpoints. `down -v` deletes Jenkins
  history, image cache and last-good tag; do not use it casually.
- Node 22 and the Docker CLI are baked into the image; no host Node install is
  required.
- DinD runs privileged. Use this setup only on a trusted local/dev host.
